# -*- coding: utf-8 -*-
"""
Created on Thu Jan 18 09:26:36 2018

@author: ylxuer
"""

from pyecharts import Style,GeoLines


style = Style(
    title_top="#fff",
    title_pos = "left",
    width="100%",
    height=600
)

style_geo = style.add(
    maptype='world',
    is_label_show=False,
    symbol=['arrow', 'arrow'],
    symbol_size=1,
    geo_normal_color="#eee",
    geo_emphasis_color="red",
    line_width=3,
    line_curve=0.2,
    line_opacity=0.6,
    geo_effect_symbol="arrow",
    geo_effect_symbolsize=5,
    label_color=['#cd5c5c', '#ffa022', '#a6c84c', '#46bee9'],
    label_pos="right",
    label_formatter="{b}",
    label_text_color="#b8860b",
    item_color='#40e0d0',
)

style_snow = style.add(
    maptype='world',
    is_label_show=False,
    symbol='pin',
    symbol_size=12,
    geo_normal_color="#eee",
    geo_emphasis_color="red",
    line_width=3,
    line_curve=0.2,
    line_opacity=0.6,
    geo_effect_symbol='circle',
    geo_effect_symbolsize=5,
    label_color=['#B4EEB4'],
    label_pos="right",
    label_formatter="{b}",
    label_text_color="#b8860b",
    item_color='#40e0d0',
)

# geolines
def geoline():
    charts = GeoLines("东方快车线路", **style.init_style)
    
    data_Syria = [
        ['阿勒颇','伊斯坦布尔']
    ]
    charts.add("陶鲁斯快车【冬星期天早5点__星期一晚七点五十分】", data_Syria,
               geo_cities_coords={
                    '阿勒颇': [37.1629,36.1990],
                    '伊斯坦布尔': [28.9843,41.0126]
                },**style_geo)
 
    data_Athens = [
        ['雅典', '贝尔格莱德']
    ]
    charts.add("雅典加挂【星期二晚八点三刻__九点十五分】", data_Athens, 
               geo_cities_coords={
                    '雅典': [23.7265,37.9714],
                    '贝尔格莱德': [20.4659,44.8117]
                },**style_geo)
        
    data_Bucharest = [
        ['布加勒斯特', '贝尔格莱德'],
        ['贝尔格莱德', '温科夫齐'],
        ['温科夫齐', '布罗德'],
        ['布罗德', '威尼斯'],
        ['威尼斯', '米兰'],
        ['米兰', '巴黎']
    ]
    charts.add("布加勒斯特加挂【星期二晚八点三刻__九点十五分】", data_Bucharest,
               geo_cities_coords={
                    '布加勒斯特': [26.1025384, 44.4267674],
                    '贝尔格莱德': [20.4659,44.8117],
                    '温科夫齐': [18.8056781, 45.2879058],
                    '布罗德': [18.018951416015625,45.1646106517254],
                    '威尼斯': [12.3358,45.4379],
                    '米兰': [9.1791,45.4702],
                    '巴黎': [2.3385,48.8602]
                },**style_geo)
    
    data_OrientExpress = [
        ['伊斯坦布尔', '贝尔格莱德'],
        ['贝尔格莱德', '温科夫齐'],
        ['温科夫齐', '布罗德'],
        ['布罗德', '威尼斯'],
        ['威尼斯', '米兰'],
        ['米兰', '巴黎'],
        ['巴黎', '加来'],
        ['加来', '伦敦']
    ]
    charts.add("东方快车【星期一晚九点__星期四】", data_OrientExpress,
               geo_cities_coords={
                    '伊斯坦布尔': [28.9843,41.0126],
                    '贝尔格莱德': [20.4659,44.8117],
                    '温科夫齐': [18.8056781, 45.2879058],
                    '布罗德': [18.018951416015625,45.1646106517254],
                    '威尼斯': [12.3358,45.4379],
                    '米兰': [9.1791,45.4702],
                    '巴黎': [2.3385,48.8602],
                    '加来': [1.845703125, 50.968805734317804],
                    '伦敦': [0.0000,51.4800]
                }, **style_geo)
    
    data_Snow = [
        ['温科夫齐', '布罗德']
    ]
    charts.add("东方快车撞入雪堆【温科夫齐晚12:18出站__星期二晚12:30】", data_Snow,
               geo_cities_coords={
                    '温科夫齐': [18.8056781, 45.2879058],
                    '布罗德': [18.018951416015625,45.1646106517254]
                },**style_snow)
                
    return charts