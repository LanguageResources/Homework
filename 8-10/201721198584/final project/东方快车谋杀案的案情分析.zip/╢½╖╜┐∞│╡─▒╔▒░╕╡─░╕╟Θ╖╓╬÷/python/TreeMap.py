from pyecharts import TreeMap

data = [
    {
        "value": 400,
        "name": '''16包厢\n哈德曼''',
    },
	{
        "value": 400,
        "name": '''15包厢\n阿巴斯诺特上校''',
    },
	{
        "value": 400,
        "name": '''14包厢\n德拉哥米罗夫公主''',
    },
	{
        "value": 400,
        "name": '''13包厢\n安德雷尼伯爵''',
    },
	{
        "value": 400,
        "name": '''12包厢\n安德雷尼伯爵夫人''',
    },
	{
        "value": 400,
        "name": '''3包厢\n哈巴特太太''',
    },
	{
        "value": 400,
        "name": '''2包厢\n死者->雷切特''',
    },
	{
        "value": 400,
        "name": '''1包厢\n侦探->赫尔克里·波洛''',
    },
	{
        "value": 400,
        "name": "10/11包厢",
		"children": [
            {
                "value": 150,
                "name": "格丽塔·奥尔松",
            },
			{
                "value": 150,
                "name": "玛丽·德贝纳姆",
            },
		]
    },
	{
        "value": 400,
        "name": "8/9包厢",
		"children": [
            {
                "value": 150,
                "name": "空",
            },
			{
                "value": 150,
                "name": "希尔德加德·施密特",
            },
		]
    },
	{
        "value": 400,
        "name": "6/7包厢",
		"children": [
            {
                "value": 150,
                "name": "空",
            },
			{
                "value": 150,
                "name": "赫克托·麦奎因",
            },
		]
    },
	{
        "value": 400,
        "name": "4/5包厢",
		"children": [
            {
                "value": 150,
                "name": "安东尼奥·福斯卡雷利",
            },
			{
                "value": 150,
                "name": "马斯特曼",
            },
		]
    },
    {
        "value": 400,
        "name": "餐车",
        
	}
]

treemap = TreeMap("", width=1200, height=100)
treemap.add("演示数据", data, is_label_show=True, label_pos='inside',
            treemap_left_depth=1)
treemap.render()