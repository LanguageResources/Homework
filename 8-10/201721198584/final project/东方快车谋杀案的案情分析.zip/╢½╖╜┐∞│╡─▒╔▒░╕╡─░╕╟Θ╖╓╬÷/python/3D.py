from pyecharts import Bar3D

bar3d = Bar3D('''\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n
          根据证词展示的斯坦布尔-加来车厢示意图 
         （23点至2点之间的人物位置）


''', width=1200, height=600)
# x_axis = [
    # "4/5", "", "", "", "6/7", "", "8/9", "10/11", "", "",
    # "1", "2", "3", "12", "13", "14", "15", "5p", "6p", "7p", "16", "9p", "10p", "11p"]
x_axis = [
    "餐车", "4/5包厢", "6/7包厢", "8/9包厢", "10/11包厢","1包厢", "2包厢", "3包厢", "12包厢", "13包厢", "14包厢", "15包厢", "16包厢"]
y_axis = [
    "",  "早上","2点", "1点45", "24点45左右", "24点左右", "23点左右"]

data = [
	[1, 0, 12],
    [1, 1, 3], [1, 2, 3], [1, 3, 3], [1, 4, 3], [1, 5, 3], [1, 6, 3],
    [1, 7, 3], [1, 8, 3], [1, 9, 3], [1, 10, 3], [1, 11, 3], [1, 12, 3],
	[2, 0, 15],
    [2, 1, 3], [2, 2, 3], [2, 3, 3], [2, 4, 3], [2, 5, 3], [2, 6, 3],
    [2, 7, 3], [2, 8, 3], [2, 9, 3], [2, 10, 3], [2, 11, 3], [2, 12, 3],
	[3, 0, 16],
    [3, 1, 4], [3, 2, 4], [3, 3, 4], [3, 4, 4], [3, 5, 4], [3, 6, 4],
    [3, 7, 4], [3, 8, 4], [3, 9, 4], [3, 10, 4], [3, 11, 4], [3, 12, 4],
	[4, 0, 17],
    [4, 1, 6], [4, 2, 6], [4, 3, 6], [4, 4, 6], [4, 5, 6], [4, 6, 6],
    [4, 7, 6], [4, 8, 6], [4, 9, 6], [4, 10, 6], [4, 11, 6], [4, 12, 6],
	[5, 0, 18],
    [5, 1, 8], [5, 2, 8], [5, 3, 8], [5, 4, 8], [5, 5, 8], [5, 6, 8],
    [5, 7, 8], [5, 8, 8], [5, 9, 8], [5, 10, 8], [5, 11, 8], [5, 12, 8],
	[6, 0, 20],
    [6, 1, 10], [6, 2, 10], [6, 3, 10], [6, 4, 10], [6, 5, 10], [6, 6, 10],
    [6, 7, 10], [6, 8, 10], [6, 9, 10], [6, 10, 10], [6, 11, 10], [6, 12, 10],
	]
	
# range_color = ['#8B4513', '#303030']
range_color = ['#313695', '#4575b4', '#74add1', '#abd9e9', '#e0f3f8', '#ffffbf',
               '#fee090', '#fdae61', '#f46d43', '#d73027', '#a50026']
bar3d.add("餐车", x_axis, y_axis, [[0, 6, 20] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("4/5包厢 马斯特曼和安东尼奥·福斯卡雷利 一直在包厢", x_axis, y_axis, [[1, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("6/7包厢 赫克托·麦奎因", x_axis, y_axis, [[2, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("8/9包厢 希尔德加德·施密特", x_axis, y_axis, [[3, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("10/11包厢 格丽塔·奥尔松和玛丽·德贝纳姆 一直在包厢", x_axis, y_axis, [[4, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("1包厢 赫尔克里·波洛 一直在包厢", x_axis, y_axis, [[5, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("2包厢 死者雷切特", x_axis, y_axis, [[6, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("3包厢 哈巴特太太 一直在包厢", x_axis, y_axis, [[7, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("12包厢 安德雷尼伯爵夫人 一直在包厢", x_axis, y_axis, [[8, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("13包厢 安德雷尼伯爵 一直在包厢", x_axis, y_axis, [[9, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
bar3d.add("14包厢 德拉戈米罗夫公主 一直在包厢", x_axis, y_axis, [[10, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("15包厢 阿巴思诺上校", x_axis, y_axis, [[11, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("16包厢 哈德曼先生", x_axis, y_axis, [[12, 6, 10] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
#######################################################
bar3d.add("餐车", x_axis, y_axis, [[0, 5, 18] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("4/5包厢 马斯特曼和安东尼奥·福斯卡雷利 一直在包厢", x_axis, y_axis, [[1, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("6/7包厢 空（赫克托·麦奎因下车）", x_axis, y_axis, [[2, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("8/9包厢 希尔德加德·施密特", x_axis, y_axis, [[3, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("10/11包厢 格丽塔·奥尔松和玛丽·德贝纳姆 一直在包厢", x_axis, y_axis, [[4, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("1包厢 赫尔克里·波洛 一直在包厢", x_axis, y_axis, [[5, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("2包厢 死者雷切特", x_axis, y_axis, [[6, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("3包厢 哈巴特太太 一直在包厢", x_axis, y_axis, [[7, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("12包厢 安德雷尼伯爵夫人 一直在包厢", x_axis, y_axis, [[8, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("13包厢 安德雷尼伯爵 一直在包厢", x_axis, y_axis, [[9, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
bar3d.add("14包厢 德拉戈米罗夫公主 一直在包厢", x_axis, y_axis, [[10, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("15包厢 空（阿巴思诺上校下车）", x_axis, y_axis, [[11, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("16包厢 哈德曼先生", x_axis, y_axis, [[12, 5, 8] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
#######################################################
bar3d.add("餐车", x_axis, y_axis, [[0, 4, 17] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("4/5包厢 马斯特曼和安东尼奥·福斯卡雷利 一直在包厢", x_axis, y_axis, [[1, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("6/7包厢 赫克托·麦奎因和阿巴思诺上校聊天", x_axis, y_axis, [[2, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("8/9包厢 空", x_axis, y_axis, [[3, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("10/11包厢 格丽塔·奥尔松和玛丽·德贝纳姆 一直在包厢", x_axis, y_axis, [[4, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("1包厢 赫尔克里·波洛 一直在包厢", x_axis, y_axis, [[5, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("2包厢 死者雷切特", x_axis, y_axis, [[6, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("3包厢 哈巴特太太 一直在包厢", x_axis, y_axis, [[7, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("12包厢 安德雷尼伯爵夫人 一直在包厢", x_axis, y_axis, [[8, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("13包厢 安德雷尼伯爵 一直在包厢", x_axis, y_axis, [[9, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
bar3d.add("14包厢 德拉戈米罗夫公主和女仆希尔德加德·施密特", x_axis, y_axis, [[10, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("15包厢 空", x_axis, y_axis, [[11, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("16包厢 哈德曼先生", x_axis, y_axis, [[12, 4, 6] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
#######################################################
bar3d.add("餐车", x_axis, y_axis, [[0, 3, 16] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("4/5包厢 马斯特曼和安东尼奥·福斯卡雷利 一直在包厢", x_axis, y_axis, [[1, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("6/7包厢 赫克托·麦奎因和阿巴思诺上校聊天", x_axis, y_axis, [[2, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("8/9包厢 希尔德加德·施密特", x_axis, y_axis, [[3, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("10/11包厢 格丽塔·奥尔松和玛丽·德贝纳姆 一直在包厢", x_axis, y_axis, [[4, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("1包厢 赫尔克里·波洛 一直在包厢", x_axis, y_axis, [[5, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("2包厢 死者雷切特", x_axis, y_axis, [[6, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("3包厢 哈巴特太太 一直在包厢", x_axis, y_axis, [[7, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("12包厢 安德雷尼伯爵夫人 一直在包厢", x_axis, y_axis, [[8, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("13包厢 安德雷尼伯爵 一直在包厢", x_axis, y_axis, [[9, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
bar3d.add("14包厢 德拉戈米罗夫公主 一直在包厢", x_axis, y_axis, [[10, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("15包厢 空", x_axis, y_axis, [[11, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("16包厢 哈德曼先生", x_axis, y_axis, [[12, 3, 4] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')				  

#######################################################
bar3d.add("餐车", x_axis, y_axis, [[0, 2, 15] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("4/5包厢 马斯特曼和安东尼奥·福斯卡雷利 一直在包厢", x_axis, y_axis, [[1, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("6/7包厢 赫克托·麦奎因", x_axis, y_axis, [[2, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("8/9包厢 希尔德加德·施密特", x_axis, y_axis, [[3, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("10/11包厢 格丽塔·奥尔松和玛丽·德贝纳姆 一直在包厢", x_axis, y_axis, [[4, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("1包厢 赫尔克里·波洛 一直在包厢", x_axis, y_axis, [[5, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("2包厢 死者雷切特", x_axis, y_axis, [[6, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("3包厢 哈巴特太太 一直在包厢", x_axis, y_axis, [[7, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("12包厢 安德雷尼伯爵夫人 一直在包厢", x_axis, y_axis, [[8, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')
bar3d.add("13包厢 安德雷尼伯爵 一直在包厢", x_axis, y_axis, [[9, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
bar3d.add("14包厢 德拉戈米罗夫公主 一直在包厢", x_axis, y_axis, [[10, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("15包厢 阿巴思诺上校", x_axis, y_axis, [[11, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')	
bar3d.add("16包厢 哈德曼先生", x_axis, y_axis, [[12, 2, 3] for d in data],
          is_visualmap=True, visual_range=[0, 20],
          visual_range_color=range_color, grid3d_width=200,
          grid3d_depth=80, grid3d_shading='lambert')		
		  
#######################################################
		  
bar3d.render()