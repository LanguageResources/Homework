# -*- coding: utf-8 -*-
"""
Created on Thu Jan 18 09:17:05 2018

@author: ylxuer
"""

from pyecharts import Page
from charts import geoline
from charts3D import bar3D

page = Page()         # page

# geolines
_geoline=geoline()
page.add(_geoline)         #  graph 1

# bar3D
_bar3D=bar3D()
page.add(_bar3D)

page.render("add_page.html")        # graph 2