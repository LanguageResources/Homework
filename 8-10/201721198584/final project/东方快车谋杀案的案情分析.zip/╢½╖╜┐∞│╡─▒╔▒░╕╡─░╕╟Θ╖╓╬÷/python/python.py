from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def home():
	return render_template('index.html')#index
	
@app.route('/People.html') #characters
def characters():
    return render_template('People.html')

@app.route('/add_page.html') #location
def location():
    return render_template('add_page.html')

@app.route('/3.html') #analyze
def analyze():
    return render_template('3.html')

@app.route('/4.html') 
def analyze1():
    return render_template('4.html')

@app.route('/5.html')
def analyze2():
    return render_template('5.html')
@app.route('/parallel-aqi.html')
def analyze3():
    return render_template('parallel-aqi.html')


if __name__ == '__main__':
    app.run()